function [CoordsU,CoordsI] = getUser_Items_Coords(uData,TrainSet)
M = 30;
baseSet = uData(TrainSet,:);

%Users Similarity computation
[baseSet] = convertToUserItemMatrix(baseSet(:,1),baseSet(:,2),baseSet(:,3));
test1 = ItemBasedKNN.createNewWithDatasets(baseSet, baseSet);
test1.k = 10;
test1.setSimilarityCalculatorTo(Similarity.COSINE);
test1.calculatePredictiveAccuracy;
X = test1.similarities;
Ind = test1.similarItemIndexes;
Y = zeros(length(X),length(X));
for i=1:length(X)
    for j=1:length(X{i})
        Y(i,Ind{i}(j)) = X{i}(j);
    end
    Y(i,i) = 1;
end
%[~, ctrs] = kmeans(Y, M);
[~,~,~,~,midx,~] = kmedoids(Y, M);
Y1 = zeros(length(X),M);
for i=1:length(X)
    for j=1:M
        Y1(i,j) = Y(i,midx(j));
    end
end

CoordsI = Y1;

%Items Similarity computation
test1 = ItemBasedKNN.createNewWithDatasets(baseSet', baseSet');
test1.k = 10;
test1.setSimilarityCalculatorTo(Similarity.COSINE);
test1.calculatePredictiveAccuracy;
X = test1.similarities;
Ind = test1.similarItemIndexes;
Y = zeros(length(X),length(X));
for i=1:length(X)
    for j=1:length(X{i})
        Y(i,Ind{i}(j)) = X{i}(j);
    end
    Y(i,i) = 1;
end
%[~, ctrs] = kmeans(Y, M);
[~,~,~,~,midx,~] = kmedoids(Y, M);
Y1 = zeros(length(X),M);
for i=1:length(X)
    for j=1:M
        Y1(i,j) = Y(i,midx(j));
    end
end


CoordsU = Y1;

end


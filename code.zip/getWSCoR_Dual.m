%Weigthing SCoR

function [RMSE,WYfit,Y1,Y2,Y3,RMSE_USER,RMSE_MOVIE,DEG_USER,DEG_MOVIE,MeanUser,VarUser,MeanMovie,VarMovie] = getWSCoR_Dual(uData,TrainSet,TestSet,MAT_SCOR,CoordsU,CoordsI,gt)
Nu = max(uData(:,1));
Ni = max(uData(:,2));
M = Nu+Ni;
V = uData(TrainSet,1) + M*uData(TrainSet,2);
V1 = MAT_SCOR(:,1) + M*MAT_SCOR(:,2);
Yfit = zeros(1,length(TestSet));
WYfit = zeros(1,length(TestSet));
Y1 = WYfit;
Y2 = WYfit;
Y3 = WYfit;

MeanUser = zeros(Nu,1);
MeanMovie = zeros(Nu,1);
VarUser = zeros(Nu,1);
VarMovie = zeros(Nu,1);

RMSE_USER = zeros(Nu,1);
RMSE_MOVIE = zeros(Ni,1);
DEG_USER = zeros(Nu,1);
DEG_MOVIE = zeros(Ni,1);
UserMovies = cell(Nu,1);
UserMoviesError = cell(Nu,1);
MoviesUser = cell(Ni,1);
MoviesUserError = cell(Ni,1);
U1 = cell(Nu,1);
M1 = cell(Ni,1);

for i=1:length(TrainSet)
    k = length(UserMovies{uData(TrainSet(i),1)})+1;
    UserMovies{uData(TrainSet(i),1)}(k) = uData(TrainSet(i),2);
    pos = find(V1 == V(i));
    pos = pos(1);
    UserMoviesError{uData(TrainSet(i),1)}(k) = uData(TrainSet(i),3)-MAT_SCOR(pos,3);
    U1{uData(TrainSet(i),1)}(k) = MAT_SCOR(pos,3);
end

for i=1:length(UserMoviesError)
    vec = UserMoviesError{i};
    DEG_USER(i) = length(vec);
    MeanUser(i) = mean(U1{i});
    VarUser(i) = var(U1{i});
    if ~isempty(vec)
        RMSE_USER(i) = (mean(vec.^2));
    end
end

for i=1:length(TrainSet)
    k = length(MoviesUser{uData(TrainSet(i),2)})+1;
    MoviesUser{uData(TrainSet(i),2)}(k) = uData(TrainSet(i),1);
    pos = find(V1 == V(i));
    pos = pos(1);
    MoviesUserError{uData(TrainSet(i),2)}(k) = uData(TrainSet(i),3)-MAT_SCOR(pos,3);
    M1{uData(TrainSet(i),2)}(k) = MAT_SCOR(pos,3);
end


for i=1:length(MoviesUserError)
    vec = MoviesUserError{i};
    DEG_MOVIE(i) = length(vec);
    MeanMovie(i) = mean(M1{i});
    VarMovie(i) = var(M1{i});
    if ~isempty(vec)
        RMSE_MOVIE(i) = (mean(vec.^2));
    end
end

V = uData(TestSet,1) + M*uData(TestSet,2);

for i=1:length(TestSet)
    pos = find(V1 == V(i));
    pos = pos(1);
    Yfit(i) = MAT_SCOR(pos,3);
    user = uData(TestSet(i),1);
    item = uData(TestSet(i),2);
    sumc = getSumC(UserMovies{user},UserMoviesError{user},item,CoordsI);
    sumcI = getSumCInv(MoviesUser{item},MoviesUserError{item},user,CoordsU);
    %sumDual = getSumCDual(UserMovies{user},UserMoviesError{user},item,CoordsI,MoviesUser{item},MoviesUserError{item},user,CoordsU);
    %Y1(i) = Yfit(i)+((sumc));
   %Y2(i) = Yfit(i)+((sumcI));
%   WYfit(i) = Yfit(i)+((sumc+sumcI)/2);
  % WYfit(i) = Yfit(i)+(sumc^3+sumcI^3) / (sumc^2+sumcI^2);
  deg1 = sqrt(length(UserMovies{user}));
  deg2 = sqrt(length(MoviesUser{item}));
   %if RMSE_USER(user) > RMSE_MOVIE(item)
   %    WYfit(i) = Yfit(i)+sumc;
   %else
   %    WYfit(i) = Yfit(i)+sumcI;
   %end
   
   
   Y1(i) =  Yfit(i);
   Y2(i) =  sumc;
   Y3(i) =  sumcI;
  
%    x = Yfit(i)+sumc;
%    prop1 = normpdf(x,MeanUser(user),0.01+sqrt(VarUser(user)))*normpdf(x,MeanMovie(item),0.01+sqrt(VarMovie(item)));
%    x = Yfit(i)+sumcI;
%    prop2 = normpdf(x,MeanUser(user),0.01+sqrt(VarUser(user)))*normpdf(x,MeanMovie(item),0.01+sqrt(VarMovie(item)));
%    
%    if prop1 > prop2
%        WYfit(i) = Y1(i)+sumc;
%    else
%        WYfit(i) = Y1(i)+sumcI;
%    end
%    
   WYfit(i) = Yfit(i)+(RMSE_MOVIE(item)*sumcI+RMSE_USER(user)*sumc) / (RMSE_USER(user)+RMSE_MOVIE(item));

   % WYfit(i) = Yfit(i)+(deg1*sumcI+deg2*sumc) / (deg1+deg2);
   % WYfit(i) = Yfit(i)+sumDual;
end

%Y_Dual = (Y1+Y2)/2;

Rmin = min(uData(:,3));
Rmax = max(uData(:,3));

WYfit = max(WYfit,Rmin);
WYfit = min(WYfit,Rmax);


%RMSED = getRMSE(gt,Y_Dual);
RMSE = getRMSE(gt,WYfit)
%RMSED

end


function [sumc] = getSumCInv(MoviesUser,MoviesUserError,user,CoordsU)
if isempty(MoviesUser)
    sumc = 0;
    return;
end
d = zeros(1,length(MoviesUser));
E = zeros(1,length(MoviesUser));
for i=1:length(MoviesUser)
    v = MoviesUser(i);
    d(i) = max(0.0000000001,norm(CoordsU(v,:)-CoordsU(user,:)));
    d(i) = d(i)^2;
    E(i) = MoviesUserError(i)/d(i);
end
sumc = sum(E);
c = sum(1./d);
sumc = sumc/c;
end

function [sumc] = getSumC(UserMovies,UserMoviesError,item,CoordsI)
if isempty(UserMovies)
    sumc = 0;
    return;
end
d = zeros(1,length(UserMovies));
E = zeros(1,length(UserMovies));
for i=1:length(UserMovies)
    v = UserMovies(i);
    d(i) = max(0.0000000001,norm(CoordsI(v,:)-CoordsI(item,:)));
    d(i) = d(i)^2;
    E(i) = UserMoviesError(i)/d(i);
end
sumc = sum(E);
c = sum(1./d);
sumc = sumc/c;
end


function [sumc] = getSumCDual(UserMovies,UserMoviesError,item,CoordsI,MoviesUser,MoviesUserError,user,CoordsU)
if isempty(UserMovies) && isempty(MoviesUser)
    sumc = 0;
    return;
end
d = zeros(1,length(MoviesUser)+length(UserMovies));
E = zeros(1,length(MoviesUser)+length(UserMovies));
for i=1:length(UserMovies)
    v = UserMovies(i);
    d(i) = max(0.0000000001,norm(CoordsI(v,:)-CoordsI(item,:)));
    d(i) = d(i)^2;
    E(i) = UserMoviesError(i)/d(i);
end

for i=1:length(MoviesUser)
    v = MoviesUser(i);
    k = i+length(UserMovies);
    d(k) = max(0.0000000001,norm(CoordsU(v,:)-CoordsU(user,:)));
    d(k) = d(k)^2;
    E(k) = MoviesUserError(i)/d(k);
end

sumc = sum(E);
c = sum(1./d);
sumc = sumc/c;
end




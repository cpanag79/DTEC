% IMPLEMENATION Of Dual Training Error based Correction Approach In [1]
% with an SCoR RS  
%[1] C. Panagiotakis, H. Papadakis, A. Papagrigoriou and P. Fragopoulou, 
%Improving Recommender Systems via a Dual Training Error based Correction Approach,   Expert Systems with Applications, 2021. 


%The datasets can be found in https://sites.google.com/site/costaspanagiotakis/research/scor-dtec  


close all;
clear all;

%%PARAMETER - SELECTION OF METHOD TO COMPUTE WEIGHTS 

%USE_WEIGHTS = 0; %Equal weights
USE_WEIGHTS = 1; %SCOR based weights are used

DATASET=3; %DATASET SELECTION

if DATASET == 3 %ML-1M
    DataDir = '/data/ML-1M/';
    [uData] = textread(sprintf('%sml1M.txt',DataDir));
    [u1Base] = textread(sprintf('%sml1MTraining.txt',DataDir));
elseif DATASET == 4 %Jester
    DataDir = '/data/Jester/';
    [uData] = textread(sprintf('%sjester.txt',DataDir));
    [u1Base] = textread(sprintf('%sjesterTraining.txt',DataDir));
elseif DATASET == 5 %Jester2
    DataDir = '/data/Jester/';
    [uData] = textread(sprintf('%sjester2.txt',DataDir));
    [u1Base] = textread(sprintf('%sjester2Training.txt',DataDir));
elseif DATASET == 6 %SN
    DataDir = '/data/sn/';
    [uData] = textread(sprintf('%ssn.txt',DataDir));
    [u1Base] = textread(sprintf('%ssnTraining.txt',DataDir));
end

if DATASET == 6 %correct format of dataset SN
    [~,~,IC] = unique(uData(:,1));
    uData(:,1) = IC;
    
    [~,~,IC] = unique(uData(:,2));
    uData(:,2) = IC;
    
    [~,~,IC] = unique(u1Base(:,1));
    u1Base(:,1) = IC;
    
    [~,~,IC] = unique(u1Base(:,2));
    u1Base(:,2) = IC;
end

%read dataset
N = size(uData,1);

TrainSet = getTrainSet(u1Base,uData);
TestSet = setdiff([1:N],TrainSet)';

[RatingsU,RatingsM] = getRats(uData(TrainSet,:));

SCOR_TRAIN0 = TrainSet;
if DATASET == 4 || DATASET == 5
    %scale to 1-5 Jester datasets 
    
    uData(:,3) = 1+(4*(uData(:,3)+10)/20);
    minR = min(uData(:,3));
    maxR = max(uData(:,3));
    
    fid = fopen('base0Training.txt','w');
    fprintf(fid,'%d %d %f\n',uData(TrainSet,:)');
    fclose(fid);
    
    fid = fopen('base0Validation.txt','w');
    fprintf(fid,'%d %d %f\n',uData');
    fclose(fid);
else
    fid = fopen('base0Training.txt','w');
    fprintf(fid,'%d %d %d %d\n',uData(TrainSet,:)');
    fclose(fid);
    
    fid = fopen('base0Validation.txt','w');
    fprintf(fid,'%d %d %d %d\n',uData');
    fclose(fid);
end


%SCOR RUN - This part can be replaced by other RS

command = 'del coords.txt';
dos(command);
for i=1:5 
    command = 'java -Xmx12300m -jar .\SCoR2.jar  base0';
    dos(command);
end

[MAT_SCOR] = textread(sprintf('base0Recommendations.txt'));
size(MAT_SCOR)
size(uData)

[Type_C,ID_C,SCOR_C] = textread('coords.txt','%c%d %s','delimiter','\n');

Nu = max(uData(:,1));
Ni = max(uData(:,2));
[CoordsU,CoordsI] = getCoords(Type_C,ID_C,SCOR_C,Nu,Ni); %%Saves the Coords to matrices CoordsU for users and CoordsI for items


gt = [];
for i=1:length(TestSet)
    u = uData(TestSet(i),1);
    v = uData(TestSet(i),2);
    gt(i) = uData(TestSet(i),3);
end
MAT_SCOR(isnan(MAT_SCOR)) = 3;
%SCoR
M = max(uData(:,1))+1;
V = uData(TestSet,1) + M*uData(TestSet,2);
V1 = MAT_SCOR(:,1) + M*MAT_SCOR(:,2);
Yfit = [];
for i=1:length(TestSet)
    pos = find(V1 == V(i));
    pos = pos(1);
    Yfit(i) = MAT_SCOR(pos,3);
end
Yfit2 = Yfit';%Recommendations of SCoR  
RMSE_SCOR = getRMSE(gt',Yfit2);

%PROPOSED Dual Training Error based Correction Approach
[Y_Dual,Y_UTEC,Y_ITEC,RMSE_Dual,RMSE_UTEC,RMSE_ITEC] = runDTEC(uData,TrainSet,TestSet,MAT_SCOR,gt,CoordsU,CoordsI,USE_WEIGHTS);

RMSE_Dual








function [RatingsU,RatingsM] = getRats(uData)
LU = zeros(1,max(uData(:,1)));
LM = zeros(1,max(uData(:,2)));

for i=1:size(uData,1)
    userID = uData(i,1);
    itemID = uData(i,2);
    RatingsU{userID}(LU(userID)+1) = uData(i,3);
    RatingsM{itemID}(LM(itemID)+1) = uData(i,3); 
    LU(userID) = LU(userID)+1;
    LM(itemID) = LM(itemID)+1;
end
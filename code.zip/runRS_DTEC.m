% IMPLEMENATION Of Dual Training Error based Correction Approach In [1]
% with an RS  
%[1] C. Panagiotakis, H. Papadakis, A. Papagrigoriou and P. Fragopoulou, 
%Improving Recommender Systems via a Dual Training Error based Correction Approach,   Expert Systems with Applications, 2021. 

%The datasets can be found in https://sites.google.com/site/costaspanagiotakis/research/scor-dtec  

%Selection of the weighting method 

USE_WEIGHTS = 0; %Equal weights  (faster method)
%USE_WEIGHTS = 1; %SCOR based weights are used (better results - see [1])

%Dataset 
% Range of dataset: [1-5] 
DataDir = '/data/ML-100k/';
[uData] = textread(sprintf('%sml100k.txt',DataDir));  %dataset Ml-1M in form N x 4 matrix (user,item, rec,x) - the last column (x) is not used
[u1Base] = textread(sprintf('%sml100kTraining.txt',DataDir)); %training dataset Ml-1M in form M x 4 matrix  (user,item, rec,x)- the last column (x) is not used

%Given Recommendations on RS (vectors)
RecTrain = textread(sprintf('%sml100k_RS_train.txt',DataDir)); %Recommendations of RS on train set form: M x 1
RecTest = textread(sprintf('%sml100k_RS_test.txt',DataDir));  %Recommendations of RS on test set   form: (N-M) x 1


%PROPOSED Dual Training Error based Correction Approach
[Y_Dual,Y_UTEC,Y_ITEC,RMSE_Dual,RMSE_UTEC,RMSE_ITEC] = getRS_DTEC(RecTrain,RecTest,USE_WEIGHTS,uData,u1Base);

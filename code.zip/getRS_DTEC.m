% IMPLEMENATION OF Dual Training Error based Correction Approach In [1]
% with SCoR 
%[1] C. Panagiotakis, H. Papadakis, A. Papagrigoriou and P. Fragopoulou, 
%Improving Recommender Systems via a Dual Training Error based Correction Approach,   Expert Systems with Applications, 2021. 

%The datasets can be found in https://sites.google.com/site/costaspanagiotakis/research/scor-dtec  

%USE_WEIGHTS = 0; %Equal weights
%USE_WEIGHTS = 1; %SCOR based weights are used

function [Y_Dual,Y_UTEC,Y_ITEC,RMSE_Dual,RMSE_UTEC,RMSE_ITEC] = getRS_DTEC(RecTrain,RecTest,USE_WEIGHTS,uData,u1Base)

RecFM = [RecTrain' RecTest']';
        
%read dataset
N = size(uData,1);

TrainSet = getTrainSet(u1Base,uData);
TestSet = setdiff([1:N],TrainSet)';


RAT_MAT = zeros(length(TrainSet)+length(TestSet),3);
gt = [];
f = [];
for i=1:length(TrainSet)
    u = uData(TrainSet(i),1);
    v = uData(TrainSet(i),2);
    gt(i) = uData(TrainSet(i),3);
    try
        f(i) =  RecFM(i);
    catch
        f(i) = 3;
    end
    RAT_MAT(i,:) = [u v f(i)];
end
f(isnan(f)) = 3;
RMSE_Train = getRMSE(f,gt);

gt = [];
f = [];
for i=1:length(TestSet)
    u = uData(TestSet(i),1);
    v = uData(TestSet(i),2);
    gt(i) = uData(TestSet(i),3);
    try
        f(i) =  RecFM(length(TrainSet)+i);
    catch
        f(i) = 3;
    end
    RAT_MAT(length(TrainSet)+i,:) = [u v f(i)];
end
f(isnan(f)) = 3;
RAT_MAT(isnan(RAT_MAT)) = 3;
RMSE_test = getRMSE(f,gt);


if USE_WEIGHTS == 1
    DATASET = 1;%it depends on the format of the dataset (see if-cases of getSCoR_Coords)
    [CoordsU,CoordsI] = getSCoR_Coords(uData,DATASET,TrainSet);
else
    CoordsU = ones(max(uData(:,1)),20);
    CoordsI = ones(max(uData(:,2)),20);
end

[Y_Dual,Y_UTEC,Y_ITEC,RMSE_Dual,RMSE_UTEC,RMSE_ITEC] = runDTEC(uData,TrainSet,TestSet,RAT_MAT,gt,CoordsU,CoordsI,USE_WEIGHTS);
RMSE_RS = RMSE_test  %RMSE of original RS
RMSE_ITEC   %RMSE of ITEC
RMSE_UTEC   %RMSE of UTEC
RMSE_Dual   %RMSE of DTEC



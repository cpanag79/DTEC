function [RMSE] = getRMSE(Y1,Y2)

v = (Y1-Y2).^2;
v = mean(v);
RMSE = sqrt(v);

end


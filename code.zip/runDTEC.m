%PROPOSED Dual Training Error based Correction Approach
% Input: 
% uData: Given Dataset, Matrix N x 3 with the triples (user,item,
% recommendation) (ground truth)
% TrainSet: Train Set vector
% TestSet: Test Set  vector
% MAT_SCOR: Matrix N x 3 with the triples (user,item, recommendation) in each row of the RS  
% gt: ground truth recommendation vector on TestSet
% USE_WEIGHTS: parameter to select the method of WEIGHTS computation 
% CoordsU,CoordsI: ScoR coordinates from users and items 
% Output: 
% Y_Dual, RMSE_Dual: Dual TEC Recommendations and its RMSE
% Y_UTEC, RMSE_UTEC: USER TEC Recommendations and its RMSE 
% Y_ITEC, RMSE_ITEC: ITEM TEC Recommendations and its RMSE

function [Y_Dual,Y_UTEC,Y_ITEC,RMSE_Dual,RMSE_UTEC,RMSE_ITEC] = runDTEC(uData,TrainSet,TestSet,MAT_SCOR,gt,CoordsU,CoordsI,USE_WEIGHTS)

if USE_WEIGHTS == 0
    CoordsU = ones(max(uData(:,1)),20);
    CoordsI = ones(max(uData(:,2)),20);
end

[RMSE_UTEC,Y_UTEC] = getUTEC(uData,TrainSet,TestSet,MAT_SCOR,CoordsI,gt); %USER TEC

[RMSE_ITEC,Y_ITEC] = getITEC(uData,TrainSet,TestSet,MAT_SCOR,CoordsU,gt);  %ITEM TEC

%Dual TEC 
Y_Dual = (Y_UTEC+Y_ITEC)/2;
RMSE_Dual = getRMSE(gt,Y_Dual);


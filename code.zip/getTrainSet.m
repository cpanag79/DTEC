function [TrainSet] = getTrainSet(u1Base,uData)
V1 = u1Base(:,1) + 0.5./u1Base(:,2);
V = uData(:,1) + 0.5./uData(:,2);

m = ismember(V,V1);
TrainSet = find(m == 1);
%ITEM TEC

function [RMSE,WYfit] = getWMEMInverse(uData,TrainSet,TestSet,MAT_SCOR,SimU,gt)
Nu = max(uData(:,1));
Ni = max(uData(:,2));
M = Nu+Ni;
V = uData(TrainSet,1) + M*uData(TrainSet,2);
V1 = MAT_SCOR(:,1) + M*MAT_SCOR(:,2);
Yfit = zeros(1,length(TestSet));
WYfit = zeros(1,length(TestSet));

MoviesUser = cell(Ni,1);
MoviesUserError = cell(Ni,1);

for i=1:length(TrainSet)
    k = length(MoviesUser{uData(TrainSet(i),2)})+1;
    MoviesUser{uData(TrainSet(i),2)}(k) = uData(TrainSet(i),1);
    pos = find(V1 == V(i));
    pos = pos(1);
    MoviesUserError{uData(TrainSet(i),2)}(k) = MAT_SCOR(pos,3) - uData(TrainSet(i),3);
end

V = uData(TestSet,1) + M*uData(TestSet,2);

for i=1:length(TestSet)
    pos = find(V1 == V(i));
    pos = pos(1);
    Yfit(i) = MAT_SCOR(pos,3);
    user = uData(TestSet(i),1);
    item = uData(TestSet(i),2);
    sumc = getSumC(MoviesUser{item},MoviesUserError{item},user,SimU);
    WYfit(i) = Yfit(i)-sumc;
    
end
Rmin = min(uData(:,3));
Rmax = max(uData(:,3));

WYfit = max(WYfit,Rmin);
WYfit = min(WYfit,Rmax);


RMSE = getRMSE(gt,WYfit);
end



function [sumc] = getSumC(MoviesUser,MoviesUserError,user,SimU)

if isempty(MoviesUser)
    sumc = 0;
    return;
end
d = zeros(1,length(MoviesUser));
E = zeros(1,length(MoviesUser));
for i=1:length(MoviesUser)
    v = MoviesUser(i);
    d(i) = SimU(user,v);
    E(i) = MoviesUserError(i)*d(i);
end
sumc = sum(E);
c = max(0.00000000001,sum(d));
sumc = sumc/c;
end







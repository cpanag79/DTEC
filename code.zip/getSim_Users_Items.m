function [SimU,SimI] = getSim_Users_Items(uData,TrainSet)
M = 30;
baseSet = uData(TrainSet,:);

%Users Similarity computation
[baseSet] = convertToUserItemMatrix(baseSet(:,1),baseSet(:,2),baseSet(:,3));
test1 = ItemBasedKNN.createNewWithDatasets(baseSet, baseSet);
test1.k = 10;
test1.setSimilarityCalculatorTo(Similarity.COSINE);
test1.calculatePredictiveAccuracy;
X = test1.similarities;
Ind = test1.similarItemIndexes;
Y = zeros(length(X),length(X));
for i=1:length(X)
    for j=1:length(X{i})
        Y(i,Ind{i}(j)) = X{i}(j);
    end
    Y(i,i) = 1;
end

SimI = Y;

%Items Similarity computation
test1 = ItemBasedKNN.createNewWithDatasets(baseSet', baseSet');
test1.k = 10;
test1.setSimilarityCalculatorTo(Similarity.COSINE);
test1.calculatePredictiveAccuracy;
X = test1.similarities;
Ind = test1.similarItemIndexes;
Y = zeros(length(X),length(X));
for i=1:length(X)
    for j=1:length(X{i})
        Y(i,Ind{i}(j)) = X{i}(j);
    end
    Y(i,i) = 1;
end

SimU = Y;

end


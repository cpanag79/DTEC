%Saves the Coords to matrices CoordsU for users and CoordsI for items 
function [CoordsU,CoordsI] = getCoords(Type_C,ID_C,SCOR_C,Nu,Ni)

vec = sscanf(SCOR_C{1},'%f');

CoordsU = zeros(Nu,length(vec));
CoordsI = zeros(Ni,length(vec));

for i=1:length(Type_C)
    vec = sscanf(SCOR_C{i},'%f');

    if Type_C(i) == 'U'
        CoordsU(ID_C(i),:) = vec';
    else
        CoordsI(ID_C(i),:) = vec';
    end
    
end

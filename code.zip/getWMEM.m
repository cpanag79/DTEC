%USER TEC

function [RMSE,WYfit] = getWMEM(uData,TrainSet,TestSet,MAT_SCOR,SimI,gt)
Nu = max(uData(:,1));
Ni = max(uData(:,2));
M = Nu+Ni;
V = uData(TrainSet,1) + M*uData(TrainSet,2);
V1 = MAT_SCOR(:,1) + M*MAT_SCOR(:,2);
Yfit = zeros(1,length(TestSet));
WYfit = zeros(1,length(TestSet));

UserMovies = cell(Nu,1);
UserMoviesError = cell(Nu,1);

for i=1:length(TrainSet)
    k = length(UserMovies{uData(TrainSet(i),1)})+1;
    UserMovies{uData(TrainSet(i),1)}(k) = uData(TrainSet(i),2);
    pos = find(V1 == V(i));
    pos = pos(1);
    UserMoviesError{uData(TrainSet(i),1)}(k) = uData(TrainSet(i),3)-MAT_SCOR(pos,3);
end

V = uData(TestSet,1) + M*uData(TestSet,2);

for i=1:length(TestSet)
    pos = find(V1 == V(i));
    pos = pos(1);
    Yfit(i) = MAT_SCOR(pos,3);
    user = uData(TestSet(i),1);
    item = uData(TestSet(i),2);
    sumc = getSumC(UserMovies{user},UserMoviesError{user},item,SimI);
    WYfit(i) = Yfit(i)+sumc;
end
Rmin = min(uData(:,3));
Rmax = max(uData(:,3));

WYfit = max(WYfit,Rmin);
WYfit = min(WYfit,Rmax);


RMSE = getRMSE(gt,WYfit);
end



function [sumc] = getSumC(UserMovies,UserMoviesError,item,SimI)

if isempty(UserMovies)
    sumc = 0;
    return;
end
d = zeros(1,length(UserMovies));
E = zeros(1,length(UserMovies));
for i=1:length(UserMovies)
    v = UserMovies(i);
    d(i) = SimI(item,v);
    E(i) = UserMoviesError(i)*d(i);
end
sumc = sum(E);
c = max(0.00000000001,sum(d));
sumc = sumc/c;
end







function [CoordsU,CoordsI] = getSCoR_Coords(uData,DATASET,TrainSet)


    if DATASET == 4 || DATASET == 5
        %scale apo 1-5
        
        
        
        fid = fopen('base0Training.txt','w');
        fprintf(fid,'%d %d %f\n',uData(TrainSet,:)');
        fclose(fid);
        
        fid = fopen('base0Validation.txt','w');
        fprintf(fid,'%d %d %f\n',uData');
        fclose(fid);
    elseif DATASET == 6
        fid = fopen('base0Training.txt','w');
        fprintf(fid,'%d %d %d\n',uData(TrainSet,:)');
        fclose(fid);
        
        fid = fopen('base0Validation.txt','w');
        fprintf(fid,'%d %d %d\n',uData');
        fclose(fid);
    else
        fid = fopen('base0Training.txt','w');
        fprintf(fid,'%d %d %d %d\n',uData(TrainSet,:)');
        fclose(fid);
        
        fid = fopen('base0Validation.txt','w');
        fprintf(fid,'%d %d %d %d\n',uData');
        fclose(fid);
    end
    
    
    command = 'del coords.txt';
    dos(command);
    for i=1:5
        command = 'java -Xmx12300m -jar .\SCoR2.jar  base0 -d 30';
        dos(command);
    end
    
    [MAT_SCOR] = textread(sprintf('base0Recommendations.txt'));
    size(MAT_SCOR)
    size(uData)
    
    %[Coord_SCOR] = textread('%c%d %f','coords.txt');
    [Type_C,ID_C,SCOR_C] = textread('coords.txt','%c%d %s','delimiter','\n');
    
    Nu = max(uData(:,1));
    Ni = max(uData(:,2));
    [CoordsU,CoordsI] = getCoords(Type_C,ID_C,SCOR_C,Nu,Ni); %%Saves the Coords to matrices CoordsU for users and CoordsI for items
end

